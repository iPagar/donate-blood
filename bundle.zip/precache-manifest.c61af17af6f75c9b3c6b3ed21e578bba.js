self.__precacheManifest = [
  {
    "revision": "23a383989dbeea3cfb75",
    "url": "./static/css/main.95c611ea.chunk.css"
  },
  {
    "revision": "23a383989dbeea3cfb75",
    "url": "./static/js/main.0d8dc80b.chunk.js"
  },
  {
    "revision": "9eb600ee07a27cdad64f",
    "url": "./static/js/runtime~main.2c977d9b.js"
  },
  {
    "revision": "1cb180d942523edebb87",
    "url": "./static/css/2.8e26d350.chunk.css"
  },
  {
    "revision": "1cb180d942523edebb87",
    "url": "./static/js/2.869adb82.chunk.js"
  },
  {
    "revision": "0ba311981e8fadd6fc2c1bdb25587825",
    "url": "./index.html"
  }
];